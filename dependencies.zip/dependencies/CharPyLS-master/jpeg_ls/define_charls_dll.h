/*
 (C) Jan de Vaan 2007-2010, all rights reserved. See the accompanying "License.txt" for licensed use.
*/


#ifndef MY_STUFF
#define MY_STUFF

# define CHARLS_STATIC

#endif
