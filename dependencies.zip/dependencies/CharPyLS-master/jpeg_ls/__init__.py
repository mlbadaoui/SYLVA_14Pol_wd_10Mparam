
from .CharLS import encode
from .CharLS import decode

from .CharLS import write
from .CharLS import read


