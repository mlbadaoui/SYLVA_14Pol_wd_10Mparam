// Copyright (c) Team CharLS. All rights reserved. See the accompanying "LICENSE.md" for licensed use.

#pragma once

#include <charls/jpegls_encoder.h>

#include <cassert>
#include <vector>
#include <fstream>
#include <charconv>
