// Copyright (c) Team CharLS. All rights reserved. See the accompanying "LICENSE.md" for licensed use.

#pragma once

void TestConformance();
void TestColorTransforms_HpImages();
void TestSampleAnnexH3();
